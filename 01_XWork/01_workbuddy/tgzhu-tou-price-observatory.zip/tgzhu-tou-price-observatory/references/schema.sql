-- ============================================================
-- 城市分时电价观察站 - SQLite 数据库初始化脚本
-- ============================================================
-- 设计说明：
-- 1. regions 表：行政区域，支持省/市/区三级 (self-referencing parent_id)
-- 2. policies 表：电价政策，记录各省份的电价政策文件
-- 3. time_periods 表：分时时段，每条时段记录包含原始名称和标准分类
-- 4. data_sources 表：数据来源，记录每条数据的来源追溯信息
-- 5. missing_records 表：缺失数据记录，标记无法找到来源的数据
-- ============================================================

-- 行政区域表
CREATE TABLE IF NOT EXISTS regions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code VARCHAR(20) UNIQUE,
    name VARCHAR(100) NOT NULL,
    level TINYINT NOT NULL,              -- 1=省, 2=市, 3=区县
    parent_id INTEGER,
    province_code VARCHAR(20),
    FOREIGN KEY (parent_id) REFERENCES regions(id)
);

-- 电价政策表
CREATE TABLE IF NOT EXISTS policies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    region_id INTEGER NOT NULL,
    title VARCHAR(255) NOT NULL,
    policy_doc_number VARCHAR(100),
    user_type VARCHAR(50) NOT NULL DEFAULT '工商业',
    voltage_level VARCHAR(50),
    season_type VARCHAR(50),
    flat_price DECIMAL(10,5),
    price_unit VARCHAR(20) DEFAULT '元/kWh',
    effective_date DATE,
    expiry_date DATE,
    source_id INTEGER,
    notes TEXT,
    data_type VARCHAR(20) DEFAULT 'real',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (region_id) REFERENCES regions(id),
    FOREIGN KEY (source_id) REFERENCES data_sources(id)
);

-- 分时时段表
CREATE TABLE IF NOT EXISTS time_periods (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    policy_id INTEGER NOT NULL,
    region_id INTEGER NOT NULL,
    season_type VARCHAR(50),
    original_name VARCHAR(50),
    standard_category VARCHAR(20) NOT NULL,  -- 尖峰/高峰/平段/低谷/深谷
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    price DECIMAL(10,5),
    float_ratio DECIMAL(5,2),
    user_type VARCHAR(50),
    voltage_level VARCHAR(50),
    data_type VARCHAR(20) DEFAULT 'real',
    FOREIGN KEY (policy_id) REFERENCES policies(id),
    FOREIGN KEY (region_id) REFERENCES regions(id)
);

-- 数据来源表
CREATE TABLE IF NOT EXISTS data_sources (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_name VARCHAR(255) NOT NULL,
    source_url VARCHAR(500),
    publish_authority VARCHAR(255),
    publish_date DATE,
    collect_date DATE,
    reliability VARCHAR(50) DEFAULT 'high',
    doc_type VARCHAR(50),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 缺失数据记录表
CREATE TABLE IF NOT EXISTS missing_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    province VARCHAR(100) NOT NULL,
    city VARCHAR(100),
    user_type VARCHAR(50),
    data_field VARCHAR(100) NOT NULL,
    search_process TEXT,
    search_keywords TEXT,
    searched_urls TEXT,
    judgment_basis TEXT,
    status VARCHAR(20) DEFAULT 'missing',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
