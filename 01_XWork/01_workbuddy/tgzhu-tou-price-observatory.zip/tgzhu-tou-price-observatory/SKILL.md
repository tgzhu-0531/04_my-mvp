---
name: tou-price-observatory
description: 搭建城市分时电价观察站MVP - 从PRD到可运行网站的全流程。包含数据搜索、SQLite/CSV双模式数据库、IIS兼容静态SPA网站。触发词：电价观察站、分时电价、TOU price。
agent_created: true
---

# 城市分时电价观察站搭建

## 目的

从一份 PRD 需求文档出发，完成"中国城市分时电价观察站"MVP 的全链路搭建：
公开资料搜索 → 政策口径判断 → 数据结构化建模 → 数据库读写 → 网站搭建 → 交付说明。

## 触发条件

当用户提到以下内容时加载此技能：
- 搭建"城市分时电价观察站"或类似电价数据查询平台
- 需要从 PRD 文档生成可运行的网站 MVP
- 涉及分时电价 / TOU / 峰谷电价的数据采集和展示
- 需要 SQLite + CSV 双模式数据访问的静态网站

## 工作流程

### 阶段 1：理解 PRD

读取用户提供的 PRD 文档（.pdf 或 .md），提取以下关键要求：

1. **数据范围**: 固定省份列表（通常为 5 个用电大省）
2. **数据来源规则**: 优先政府官网，禁止编造数据
3. **数据访问**: SQLite + CSV 双模式，JSON 配置文件切换
4. **数据建模**: regions / policies / time_periods / data_sources / missing_records 五表
5. **网站功能**: 首页、省份查询、电价曲线、数据源中心、缺失说明、方法说明
6. **部署要求**: Windows IIS / GitHub Pages 静态兼容，index.html 默认首页，全站 UTF-8
7. **交付物**: 网站代码、SQLite 脚本、CSV 数据、数据字典、README、已知限制

### 阶段 2：搜索公开数据

对每个目标省份，在以下渠道搜索分时电价政策文件：

- **省级发改委**官网 → "分时电价" "峰谷电价" 关键词
- **电网公司**官网（国网/南网省级公司）→ 代理购电价格公告
- **政府公告** → 政策文件、PDF 附件

确认每条数据的：
- 来源 URL 可访问
- 发布机构和发布时间
- 时段划分、浮动比例、价格水平
- 适用的用户类型和电压等级

无法找到的数据 → 记录到 missing_records，描述检索过程和判断依据。

### 阶段 3：数据建模

设计以下 5 张表：

1. **regions**: 行政区域（省/市/区三级，parent_id 自引用）
2. **policies**: 电价政策（文号、用户类型、电压等级、季节、平段电价）
3. **time_periods**: 分时时段（原始名称、标准分类、起止时间、电价）
4. **data_sources**: 数据来源（URL、机构、时间、可信度）
5. **missing_records**: 缺失数据记录（检索过程、判断依据）

建表 SQL 参考 `references/schema.sql`。

### 阶段 4：架构选择

根据 PRD 的部署要求（IIS / GitHub Pages），选择 **静态 SPA + 可选后端** 架构：

```
index.html         ← IIS 默认首页，SPA 入口
config.json        ← JSON 配置，selected 字段切换 csv / sqlite
js/
  data-loader.js   ← 统一数据访问层，自动识别数据源模式
  charts.js        ← Chart.js 电价曲线绘制（单省 + 多省叠图）
  main.js          ← SPA 路由 + 页面渲染 + 可折叠分区系统
css/style.css      ← 简约数据面板风格
server/
  app.py           ← Flask API（仅 sqlite 模式本地验证）
  data_import.py   ← 数据库初始化 + CSV 导出
data/
  schema.sql       ← 建表脚本
  seed.sql         ← 种子数据
  csv/             ← CSV 数据文件（导出）
```

### 阶段 5：首页设计要点

根据 PRD §11 要求：

1. **标题区** — 简洁，不展示技术信息（无"数据源/编码"等）
2. **数据摘要条** — 一行展示"已收录 N 省 · M 条政策 · K 个来源"
3. **分析结论** — 基于数据的一句话结论，不得主观编造
4. **对比表** — Top5 省份尖/峰/平/谷/深谷 + 峰谷价差 + 数据状态，默认折叠
5. **对比曲线** — 五省 24h 叠图，默认展开
6. **省份卡片** — 快速入口，默认折叠
7. **可折叠** — 所有内容分区可折叠，状态存 localStorage

### 阶段 6：常见陷阱

| 问题 | 原因 | 修复 |
|------|------|------|
| CSV 表头是数字 | `PRAGMA table_info` 的 `row[0]` 是 cid | 用 `row[1]` 取字段名 |
| PriceCharts 未定义 | IIFE 漏了 `})();` 闭合 | 检查文件末尾闭合 |
| mode.toUpperCase 错误 | 忘了 `await` async 函数 | 调用 async 函数要有 await |
| 首页省份 0 | CSV 表头错误导致 filterRows 不匹配 | 同上，重新导出 CSV |

### 阶段 7：验证清单

- [ ] 本地 HTTP 服务器可访问首页
- [ ] 首页展示 5 省数据，无 JS 错误
- [ ] 省份详情页可正常打开，显示时段表 + 曲线
- [ ] 数据源中心显示 7 条来源
- [ ] 缺失说明页显示 5 条记录
- [ ] csv 模式：修改 config.json 的 selected 为 "csv"
- [ ] sqlite 模式：修改 selected 为 "sqlite"，启动 server/app.py
- [ ] 全站 UTF-8 无乱码
